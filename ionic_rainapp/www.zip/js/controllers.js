angular.module('starter.controllers', [])

.controller('SettingsCtrl', ['$scope', 'adalAuthenticationService', '$location', function($scope, adalService, $location) {

  $scope.logout = function() {
  	adalService.logOut();
  	// $location.path("/login");
  }
  
}]);
