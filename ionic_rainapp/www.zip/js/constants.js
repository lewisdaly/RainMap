angular.module('rainapp-constants',[])  
  .constant('apiUrl', 'http://202.158.216.65')
  .constant('debug', '1');